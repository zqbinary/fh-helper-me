{
    "java-only-comment": {
        "name": "截取java备注",
        "tips": "我是 java-only-comment 的描述信息！你可以在这里修改！",
        "icon": "➸",
        "noPage": false,
        "contentScriptJs": false,
        "contentScriptCss": false,
        "updateUrl": null
    }
}